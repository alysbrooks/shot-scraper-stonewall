var NPMap;!function(){var a=window.location.search;if(a){var e=new RegExp("^.+?mapid=(.+?)(&.+|$)","ig"),n=a.replace(e,"$1");

const getParams = (app, proj, act) => ({q: `SELECT pt_update_action('${app}','${proj}','${act}')`});
const mapId = n;
reqwest({url: 'https://carto.nps.gov/user/parktiles/api/v2/sql',method:'get',data:getParams('builder', mapId, document.referrer.length ?  document.referrer : window.location),type:'html'});

a.match(e)?reqwest({success:function(a){var e=document.createElement("script");if("function"==typeof loadCallback&&loadCallback(a),a.isCustom)e.src=a.urlScript;else{var n="2.0.1";NPMap=a,"function"==typeof readyCallback&&(NPMap.events=[{fn:readyCallback,type:"load"}]),NPMap.meta&&NPMap.meta.npmapjsVersion&&(n=NPMap.meta.npmapjsVersion),e.src="//www.nps.gov/lib/npmap.js/"+n+"/npmap-bootstrap.min.js"}document.body.appendChild(e)},type:"jsonp",url:"//www.nps.gov/maps/builder/configs/"+n+".jsonp?callback=callback"}):document.getElementById("map").innerHTML="<p>There was an error loading the map.</p>"}}();
