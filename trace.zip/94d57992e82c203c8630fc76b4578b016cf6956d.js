/*
 Quantcast measurement tag
 Copyright (c) 2008-2024, Quantcast Corp.
*/
'use strict';(function(a,b,c){__qc("rules",[a])})("p-LXk7P8me4wyVn",window,document);